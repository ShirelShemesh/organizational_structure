﻿using System;
using System.Collections.Generic;
using System.IO;
namespace org_structure.Models
{
    public class Employee1 
    {
        protected String first_name { get; set; }
        protected String last_name { get; set; }
        protected String position { get; set; }
    }
    public class EmployeeList
    {
        public List<String> Employee { get; set; }
    }

        public class Employee
    {
        protected String first_name = "";
        protected String last_name = "";
        protected String position = "";

        protected Manager manager;
        protected List<Task> tasks;

        public Employee(String first, String last, String pos)
        {
            this.first_name = first;
            this.last_name = last;
            this.position = pos;
            tasks = new List<Task>();
        }

        protected void Update_direct_manager(Manager manager)
        {
            this.manager = manager;
            manager.Add_employee(this);
        }

        public void Receive_task(Task new_task)
        {
            tasks.Add(new_task);
        }

        public List<Task> Get_tasks()
        {
            return tasks;
        }

        public void Submit_report(String text)
        {
            manager.Receive_report(new Report(text), this);
        }


    }

    public class Manager : Employee
    {
        private List<Tuple<Report, Employee>> reports = new List<Tuple<Report, Employee>>();
        private List<Employee> subordinates;

        public Manager(String first, String last, String pos) : base(first, last, pos)
        {
            base.Update_direct_manager(this);
            subordinates = new List<Employee>();
        }

        public void Add_employee(Employee emp)
        {
            subordinates.Add(emp);
        }

        public void Assign_task(Employee emp, String text, string d, string m, string y)
        {
            emp.Receive_task(new Task(text, d, m, y));
        }

        public void Receive_report(Report rep, Employee emp)
        {
            reports.Add(Tuple.Create(rep, emp));
        }

        public List<Tuple<Report, Employee>> Get_reports()
        {
            return reports;
        }

    }

    public class Task
    {
        private String assign_date;
        private String due_date;
        private String text = "";
        
        public Task(String text, String d, String m, String y)
        {
            //Date today = new Date();
            //Date due = new Date(d, m, y);

            assign_date = new Date().Get_date();
            due_date = new Date(d, m, y).Get_date();

            this.text = text;
        }

        // Getters:

        public String Get_assign_date()
        {
            return assign_date;
        }

        public String Get_due_date()
        {
            return due_date;
        }

        public String Get_text()
        {
            return text;
        }
    }

    public class Report
    {
        private String date;
        private String text = "";

        public Report(String text)
        {
            date = new Date().Get_date();
            this.text = text;
        }

        // Getters:

        public String Get_date()
        {
            return date;
        }

        public String Get_text()
        {
            return text;
        }
    }

    public class Date
    {
        private DateTime date;

        public Date()
        {
            date = DateTime.Today;
        }

        public Date(String day, String month, String year)
        {
            String str_date = String.Format(day, '/', month, '/', year);

            if (!DateTime.TryParse(str_date, out date))
            {
                try { throw new Exception("Wrong date."); }
                catch (Exception)
                {
                    Console.WriteLine("Please try again");
                }
            }
            else if (date < DateTime.Now)
            {
                try { throw new Exception("Due date cannot be in the past."); }
                catch (Exception)
                {
                    Console.WriteLine("Please try again");
                }
            }
        }

        public String Get_date()
        {
            return date.ToShortDateString();
        }
    }
}
