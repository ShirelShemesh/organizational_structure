﻿using System;
using System.IO;
using Newtonsoft.Json;
using System.Collections.Generic;
using Newtonsoft.Json.Linq;

namespace org_structure.Models
{
    public class HomeViewModel
    {
        public static String LoadEmployeeList()
        {
            string json = "";
            EmployeeList items = new EmployeeList();
            string dir = System.IO.Path.GetDirectoryName(
            System.Reflection.Assembly.GetExecutingAssembly().Location);

            string file = dir + @"/js/Employee_list.json";
            using (StreamReader r = new StreamReader(file))
            {
                json = r.ReadToEnd();
            }
            return json;
        }


    }
}
