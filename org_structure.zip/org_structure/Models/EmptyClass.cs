﻿using System;
namespace org_structure.Models
{
    public class EmptyClass
    {
        public EmptyClass()
        {
        }
    }
}
