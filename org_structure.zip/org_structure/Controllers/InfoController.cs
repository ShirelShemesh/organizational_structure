﻿using System;
namespace org_structure.Controllers
{
    public class InfoController
    {
       

        public InfoController()
        {
        }
    }
}
