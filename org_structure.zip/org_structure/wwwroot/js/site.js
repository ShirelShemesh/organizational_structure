﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.

// Write your JavaScript code.


//report();
function report() {
    var app = angular.module('repApp', []);
    app.controller('formCtrl', function ($scope) {
        $scope.master = {text: "" };
        $scope.cancel = function () {
            $scope.user = angular.copy($scope.master);
        };
        $scope.cancel();
    });
}

function assign_task() {
    var app = angular.module('taskApp', []);
    app.controller('formCtrl', function ($scope) {
        $scope.master = { text: "", due_date: "/ / "};
        $scope.cancel = function () {
            $scope.user = angular.copy($scope.master);
        };
        $scope.cancel();
    });
}


var app = angular.module('plunker', ['ui.bootstrap']);

app.controller('ModalCtrl', function ($scope, $uibModal) {

    $scope.open = function () {
        var modalInstance = $uibModal.open({
            templateUrl: "~/popups/Report_content.html",
            controller: "ModalContentCtrl",
            size: '',
        });

        modalInstance.result.then(function (response) {
            $scope.result = `${response} button hitted`;
        });

    };
})

app.controller('ModalContentCtrl', function ($scope, $uibModalInstance) {

    $scope.submit = function () {
        $uibModalInstance.close("submit");
    }

    $scope.cancel = function () {
        $uibModalInstance.dismiss();
    }

});
